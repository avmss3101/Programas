// Obtem o tri�ngulo de Pascal usando a recorr�ncia:
// Comb(i,0) = 1;  
// Comb(n,p) = 0, se n > p;  
// Comp(n,p) = Comb(n-1,p)+Comb(n-1,p-1); nos outros casos
#include <iostream>
using namespace std;

int n, p;  long long int C[1001][1001];

void TrianguloPascal(int n)
{   int i, p;
    C[0][0] = 1; for (p=1; p<=1000; p++) C[0][p]=0;
    for (i=1; i<=n; i++)
    {   C[i][0]=1;
        for (p=1; p<=n; p++) C[i][p]=C[i-1][p]+C[i-1][p-1];
    }      
}

int main()
{    TrianguloPascal(1000);
     while (1)
    {   cout << "informe n e p: ";
        cin >> n >> p;
        if (!n) break;
        cout <<endl << "C[" << n << "," << p << "] = " << C[n][p] << endl << endl;
    }
}
