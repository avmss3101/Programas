#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>

#define tamanhoMaxMatriz 10001
#define imprimirDetalhes true

using namespace std;

double M[tamanhoMaxMatriz][tamanhoMaxMatriz+1];
double TEMP;
int n;
double det;

int imprimirMatriz(const string &output)
{
	cout << endl;
	cout << setw(8*(n+2)) << setfill('-') << "" << endl;
	cout << output << endl;
	cout << setw(8*(n+2)) << setfill('-') << "" << endl;
	for(int i=0; i<n; i++)
	{
		for(int j=0; j<n+1; j++)
		{
			cout << setw(8) << right << setfill(' ') << setprecision(3) << M[i][j];
			cout << " ";
		}
		cout << endl;
	}
	cout << setw(8*(n+2)) << setfill('-') << "" << endl;
	cout << endl;

	return 0;
}

// Procedimento de calculo de Triangularizacao. Determinante tambem e calculado nesta funcao e salvo na variavel global det.
int triangularizacao()
{
	double pivo, tmp;
	int melhorPivo;
	bool ind = false, imp = false;
	det = 1;

	for(int i=0; i<n;i++)
	{
		melhorPivo = i;
		for(int j=i;j<n;j++)
		{
			if(max( fabs(M[j][i]), fabs(M[melhorPivo][i]) ) == fabs(M[j][i]))
				melhorPivo = j;
		}

		if(melhorPivo != i){
			for(int j=0; j<n+1; j++){
				TEMP = M[i][j];
				M[i][j] = M[melhorPivo][j];
				M[melhorPivo][j] = TEMP;
			}
			det *= -1;
		}
		
		if(M[i][i] == 0)
		{
			if( M[i][n+1]==0 ) ind = true;
			else imp = true;
			det = 0;
			break;
		}
		else
		{
			pivo = M[i][i];
			det *= pivo;

			for(int j=i;j<n+1;j++)
			{
				M[i][j] /= pivo;
			}
			for(int j=i+1; j<n; j++)
			{
				pivo = -M[j][i];
				M[j][i] = 0;
				for(int k=i+1; k<n+1;k++) M[j][k] += pivo*M[i][k];
			}
		}
	}

	if(imprimirDetalhes) imprimirMatriz("TRIANGULARIZACAO");

	return 0;
}

int calculoRetroativo()
{
	for(int i=n-1; i>=1; i--){
		for(int j=i-1; j>=0; j--)
		{
			M[j][n] -= M[j][i]*M[i][n];
			M[j][i] = 0;
		}
	}

	if(imprimirDetalhes) imprimirMatriz("CALCULO RETROATIVO");

	return 0;
}

int imprimirDeterminante(){
	cout << "DETERMINANTE = " << fixed << det << endl;
}


int main()
{
	/* 
	
	---- EXEMPLO DE ENTRADA ----
	2x + 3y + 2z = 4
	9x + 2y + 5z = 8
	-x + 2y +  z = 1

	 2 3 2 4
	 9 2 5 8
	-1 2 1 1

	Entrada:
	2
	3
	2
	4
	9
	2
	5
	8
	-1
	2
	1
	1

	Caso queira somente utilizar uma matriz NxN, para calcular o determinante por exemplo, preencha a coluna N+1 com um valor double x qualquer

	1 1 1 x
	1 1 1 x
	1 1 1 x

	Entrada:
	1
	1
	1
	x
	1
	1
	1
	x
	1
	1
	1
	x

	*/

	n = 6; // Ordem da Matriz

	// Gerador de Matriz Aleatória de Ordem N com valores entre -50 e 50
	for (int i=0;i<n;i++){
		for(int j=0; j<=n; j++)
		{
			M[i][j] = (rand()%100 - 50)/3;
		}
	}

	if(imprimirDetalhes) imprimirMatriz("MATRIZ INICIAL");
	triangularizacao();
	calculoRetroativo();
	if(imprimirDetalhes) imprimirDeterminante();

	return 0;
}