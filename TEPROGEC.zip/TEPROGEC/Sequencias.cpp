// Algoritmos para Sequencias: 
// SCM (Subequencia Crescente Maxima), 
// SCSM (Sequencia Consecutiva de Soma Maxima),
// SMC (Subsequencia Maxima Comum)
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;
int T[1000], S[1000], O[1000], n, m, kscm, TM[1001][1001];
char A[1001], B[1001], C[1001];

int SCM() {
    int j, k = 1;
	T[1] = S[1];   O[1] = 1; 	
	for( int i = 2; i <= n; i++ ) {
        if( S[i] > T[k] ) {
            T[++k] = S[i];    O[i] = k;
        } else {
			j = lower_bound( T, T + k, S[i] ) - T;           
            if( S[i] > T[j] )  j++;           
            T[j] = S[i];  O[i] = j;
        }
    }
    
    cout << "T = ";  for( int i = 1; i <= k; i++ )
		cout << T[i] << " ";  cout<<endl;
    cout << "O = ";  for( int i = 1; i <= n; i++ )
		cout << O[i] << " ";  cout<<endl;    
    return k;
}

void ImprimeSCM( int i, int j, int m ) {
     if( j > 0 ) {
         if( ( O[i] == j ) && ( S[i] < m ) ) {
             ImprimeSCM( i-1, j-1, S[i] );
             cout << S[i] << " ";
         }
         else ImprimeSCM( i-1, j, m );
     }
}

void SCSM(){
    int sm, cm, fm, ss, cs, fs;
	sm = cm = fm = ss = cs = fs = 0;
	
	for( int i = 1; i <= n; i++ ) {
		if( ( ss + S[i] ) >= 0 ) {
			ss=ss + S[i];
			fs=i;
			if( cs == 0 ) cs=i;
			if( ss > sm ) {
                sm=ss;   cm=cs;   fm=fs;
            }
        }
		else {
			ss = cs = fs = 0;
        }
	}
	cout << endl << endl << "Soma Maxima = " << sm;
}

void SMC(){
	n = strlen(A);
	m = strlen(B);
    for( int i=1; i<=n; i++ ) TM[i][0]=0;
    for( int j=1; j<=m; j++ ) TM[0][j]=0;    
	for( int i=1; i<=n; i++ ) {
		for( int j=1; j<=m; j++ ) {
			if( A[i-1] == B[j-1] )
				TM[i][j] = TM[i-1][j-1]+1;
			else
				TM[i][j] = max(TM[i-1][j], TM[i][j-1]);
		}
	}
}

void GeraSMC(int i, int j, int k){
	if( k > 0 ) {
		if( A[i-1] == B[j-1] ) {
			 k--; i--; j--;
			 C[k] = A[i];
        }
		else if( TM[i-1][j] == k )
			i--;
		else
			j--;
		GeraSMC(i, j, k);
    }
}

int main()
{
	cout<<"n para SCM: "; cin >> n;
    cout <<"Valores: ";
    
    for( int i = 1; i <= n; i++ )
		cin >> S[i];
    
    kscm = SCM();
    cout << endl << "Tamanho da SCM: " << kscm;
    cout<<"  SCM: ";
    ImprimeSCM( n, kscm, 2000000000 );
    
    cout << endl << endl << "n para SCSM: ";
    cin >> n;
    cout << "Valores: ";
    
    for( int i = 1; i <= n; i++ )
		cin >> S[i];    
		
    SCSM();

    cout << endl << endl << "Strings A e B para SMC: " << endl; 
    cin >> A >> B; 
    SMC();
    cout << endl << "Tamanho da subsequencia maxima comum = " << TM[n][m];
    GeraSMC( n, m, TM[n][m] );
    C[TM[n][m]] = '\0'; 
    cout << " SMC: "<< C <<endl;
  
    cin >> n;
    return 0;
}
