//RMQ com �rvore de Segmentos e Array Esparso
#include <iostream>
#include <cmath>
#include <cstring>

#define INF 1000000000
using namespace std;

int N;
int A[1000000], B[1000], ST[3000000], M[1000000][25];

//GERAL

int menor(int a, int b) {
	if (a==INF) return b;
	if (b==INF) return a;
	return (A[b]>A[a]) ? a : b;
}

//SOLU��O ALTERNATIVA (Decomposi��o em Blocos)

void decompoe() {
	double r = sqrt(N);
	int i,j,m,mp,rt,rp,pos;
	rt = (int) ceil(r); rp = (int) r;
	for(i=0;i<rt;++i) {
		m=INF; mp=-1;
		for(j=0;j<rp&&(i*rp+j)<N;++j) {
			pos=i*rp+j;
			if (A[pos]<m) {m=A[pos]; mp=pos;}
		}
		B[i]=mp;
	}
}

int queryB(int c, int f) {
	int i,r,bc,bf,m,mp;
	m=INF; mp=-1;
	r = (int) sqrt(N);
	bc = c/r + (c%r!=0); //Determina blocos intermedi�rios
	bf = (f+1)/r - 1;
	if (bc<=bf) {
		for(i=bc;i<=bf;++i) { //RMQ entre os blocos
			if (A[B[i]] < m) {m=A[B[i]]; mp = B[i];}
		}
		for(i=c;i<r*bc;++i) { //do come�o at� o primeiro bloco
			if (A[i] < m) {m=A[i]; mp=i;}
		}
		for(i=r*(bf+1);i<=f;++i) { //do fim do �ltimo bloco at� o final
			if (A[i] < m) {m=A[i]; mp=i;}
		}
	} else {
		for(i=c;i<=f;++i) { //RMQ simples
			if (A[i] < m) {m=A[i]; mp=i;}
		}
	}
	return mp;
}

//////////////////////////////////////////////

//SOLU��O COM SEGMENT TREE

int segmentTree(int no, int i, int j) {
	if (i==j)	ST[no]=i;
	else {
		int k = (i+j)/2;
		segmentTree(2*no,i,k);
		segmentTree(2*no+1,k+1,j);
		ST[no] = menor(ST[2*no],ST[2*no+1]);
	}
	return 0;
}

int queryST(int no, int c, int f, int i, int j) {
	if (c >= i && f <= j) 		{return ST[no];}
	else if (i > f || j < c)	return INF;
	else {
		int k, p1, p2;
		k=(c+f)/2;
		p1 = queryST(2*no, c, k, i, j);
		p2 = queryST(2*no+1, k+1, f, i, j);
		return menor(p1,p2);
	}
}

//////////////////////////////////////////////

//SOLU��O COM ARRAY ESPARSO

void arrayEsparso() {
	int i, j;
    for (i = 0; i < N; ++i) M[i][0] = i;
    for (j = 1; 1<<j <= N; ++j)
        for (i = 0; i+(1<<j)-1 < N; ++i) {
        	M[i][j] = menor(M[i][j-1],M[i+(1<<(j-1))][j-1]);
        }
}

int queryAE(int c, int f) {
	int k = (int) log2(f-c-1);
	return menor(M[c][k], M[f-(1<<k)+1][k]);
}

//////////////////////////////////////////////

int main() {
	int i,j;
	//Leitura do Array
	cout<<"Digite N : "; cin>>N;
	cout<<"Digite os elementos do array:"; for(i=0;i<N;++i) cin>>A[i];
	
	//Pr�-processamento
	decompoe(); //Solu��o alternativa apenas
	memset(ST, -1, sizeof(ST)); 
    segmentTree(1,0,N-1); //Segment Tree apenas
	arrayEsparso(); //Array Esparso apenas
	
	//Leitura das consultas
	cout<<"Digite as consultas RMQ(i,j):";
	while(cin>>i>>j) {
		//Processamento
		cout<<"Solucao por decomposicao: RMQ("<<i<<","<<j<<") = "<<queryB(i,j)<<endl;
		cout<<"Solucao por segment tree: RMQ("<<i<<","<<j<<") = "<<queryST(1, 0, N-1, i, j)<<endl;
		cout<<"Solucao por array esparso: RMQ("<<i<<","<<j<<") = "<<queryAE(i,j)<<endl;
	}
	return 0;
}
