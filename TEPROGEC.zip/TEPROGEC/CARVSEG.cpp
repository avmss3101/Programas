//RMQ com �rvore de Segmentos e Array Esparso
#include <iostream>
#include <cmath>
#include <cstring>

using namespace std;
struct seg{ int c; int f; };

int AS[1000000], maxf;
seg S[1000];

//////////////////////////////////////////////
void Imprime(int r, int e, int d){
     int k = (e+d)/2;
     if (AS[r]==-1) return;
     if (AS[r] > 0) cout <<e<<"-"<<d<<" ("<<AS[r]<<") ";
     else{
         Imprime(2*r, e, k);
         Imprime(2*r+1, k+1, d);    
     }
     return;
}
void Insere(int r, int e, int d, int c, int f, int v){
    int k=(e+d)/2;
    //cout<<"teste "<<r<<" "<<e<<" "<<d<<" "<<c<<" "<<f<<" "<<v<<" "<<k<<" "<<AS[r]<<endl;  cin.get();
    if ((c == e) && (f == d) && (AS[r] != 0)){
            if (AS[r] == -1) AS[r]=v;
            else AS[r]+=v;   
            return;
    }
    if (AS[r] > 0){
        Insere(2*r, e, k, e, k, AS[r]);
        Insere(2*r+1, k+1, d, k+1, d, AS[r]);
    }
    if (c <=k) Insere(2*r, e, k, c, min(k, f), v);
    if (f > k) Insere (2*r+1, k+1, d, max(c,k+1), f, v);
    AS[r] = 0; 
    return;   
}
int main() {
	int i, j, n;
	while(true){
         n = rand()%20+1;   maxf=0;  cout<<"Segmentos:"<<endl;
         for (i=1; i<=n; i++){
             S[i].c = rand()%1000+1;  S[i].f = S[i].c+rand()%1000;
             if (S[i].f > maxf) maxf=S[i].f;
             cout<<S[i].c<<" "<<S[i].f<<endl;
         }
         for (i=1; i<4*maxf; i++) AS[i]=-1;
         for (i=1; i<=n; i++)Insere(1, 1, maxf, S[i].c, S[i].f, 1);
         cout<<"contagem de sobrepoosicoes:"<<endl;
         Imprime(1, 1, maxf);
         //for (i=1; i< 4*maxf; i++) cout<<AS[i]<<" "; cout<<endl;
         cout<<endl;  cin.get();
    }
	return 0;
}
