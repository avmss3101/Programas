// Este programa l� um string e separa e apresenta suas palavras 
#include <iostream>
#include <sstream>
using namespace std;

int main()
{   string linha;
    string st;
    istringstream ss;
    while(true){    
        ss.clear();
        getline(cin, linha) ;
        ss.str(linha);
        while(ss >> st) { cout << st << endl; }
    }    
    return 0;
}
