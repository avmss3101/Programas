#include<iostream>
using namespace std;
/* Representa��o usada para big number:
       vetor de tamanho TB+1. A posi��o 0 guarda o sinal  os d�gitos do n�mero 
       s�o guardados cada um em uma posi��o, ajustados pela direita.
   Fun��es desenvolvidas:          
       Convpb: converte um n�mero pequeno para a representa��o de big number,
               devolvendo um big number, como par�metro
       Somabn: soma dois big numbers positivos, devolvendo um bignumber como par�metro.
       Multpb: multiplica um pequeno n�mero por um grande n�mero, devolvendo
               um grande n�mero como par�metro. 
       Imprimebn: imprime um big number;
*/ 
const int TB = 101;
typedef int bignum[TB+1];
int a, b;  bignum B1, B2, B3;

void Convpnbn(int a, bignum B){
	if(a < 0){ B[0]=-1;  a=-a; }
	else B[0]=1;
	for(int i=TB; i>=1; i--){
		B[i]=a%10; a /= 10;	
	}
}

void Somabn(bignum B1, bignum B2, bignum B3){//B3 = B1+B2
	int i,v1,k;
	v1=0;; B3[0]=1;
    for (i=TB; i>0; i--){
        k= B1[i]+B2[i]+v1;
        B3[i]= k % 10;
        v1= k / 10;
    }
}
void Multpnbn(int n, bignum B1, bignum B2){//B2 = n*B1
	int i,v1,k;
	v1=0;; B2[0]=1;
    for (i=TB; i>0; i--){
        k= B1[i]*n+v1;
        B2[i]= k % 10;
        v1= k / 10;
    }
}

void Imprimebn(bignum B){
	int i,k=1;	
	if(B[0]==-1) cout<<"-";
	while( (k < TB) && (!B[k])) k++;
	for(i=k; i<=TB; i++) cout<<B[i];  cout<<endl;
}

int main(){
	while (true){
        cout <<"a b ="; cin >> a>>b;
        //Calcula a^b
        Convpnbn(a,B1);
        for (int i=2; i<=b; i++) Multpnbn(a,B1,B1);
        cout<<a<<"^"<<b<<" = ";
        Imprimebn(B1);
        //Calcula b^a       
        Convpnbn(b,B2);
        for (int i=2; i<=a; i++) Multpnbn(b,B2,B2);
        cout<<b<<"^"<<a<<" = ";
        Imprimebn(B2);
        //Faz a soma;
        Somabn(B1,B2,B3);
        cout<<a<<"^"<<b<<" + "<<b<<"^"<<a<<" = ";
        Imprimebn(B3);        
    }
	return 0;	
}


