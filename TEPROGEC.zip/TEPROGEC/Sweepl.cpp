//Exemplo de Sweep Line:
//determina��o da �rea de intersec��o de v�rios ret�ngulos em um grid
#include <stdio.h>
#include <stdlib.h>
typedef struct{int x1,y1,x2,y2;} retangulo;
int gpr, gw, gh, ga;
    retangulo R[10000];

int min(int a, int b)
{  if (a < b) return a;  else return b;
}
int max(int a, int b)
{  if (a > b) return a;  else return b;
}
void Leordena()
{   R[1].x1 =  20;  R[1].y1 = 30;  R[1].x2 = 50;  R[1].y2 = 60;
    R[2].x1 =  40;  R[2].y1 = 10;  R[2].x2 = 90;  R[2].y2 = 40;
    R[3].x1 =  40;  R[3].y1 = 50;  R[3].x2 = 90;  R[3].y2 = 80;
    R[4].x1 =  60;  R[4].y1 = 0;   R[4].x2 = 70;  R[4].y2 = 100;
    R[5].x1 =  80;  R[5].y1 =  0;  R[5].x2 = 100; R[5].y2 = 60;
    gpr = 5;
}
void Sweep (int h1, int h2, int ux, int d, int p)
/* O significado dos par�metros � o seguinte: a varredura est� sendo feita
entre as ordenadas h1 e h2, tendo sido ux o �ltimo ponto visitado. A partir
desse ponto, deve-se considerar uma �rea relativa ao comprimento d. p � o
ponto da ordena��o onde se deve continuar a varredura.*/
{  if (p <= gpr)
   {   if ((R[p].y2 > h1) && (R[p].y1 < h2))
       {  /*Contabiliza a �rea e acerta d */
          if (R[p].x1 >= (ux+ d)) {  ga=ga +(h2-h1)*d;  d = 0;}
          else {  ga = ga+(h2-h1)*(R[p].x1 - ux);  d=d - (R[p].x1 - ux);}
          /*Se necess�rio, subdivide a regi�o e continua a varredura*/
          if (h2 > R[p].y2) Sweep(R[p].y2, h2, R[p].x1, d, p+1);
          if (h1 < R[p].y1) Sweep(h1, R[p].y1, R[p].x1, d, p+1);
          Sweep(max(h1, R[p].y1), min(h2, R[p].y2), R[p].x1,
                max(d, R[p].x2-R[p].x1), p+1);
       } 
       else Sweep(h1, h2, ux, d, p+1);
   }    
}
int main()
{   /*Define grid */
    gh = 100;  gw = 100;
    /*L� e ordena dados segundo a abcissa*/
    Leordena();
    /*Acrescenta sentinela*/
    gpr++; R[gpr].x1 =  gw; R[gpr].y1 = 0;  R[gpr].x2 = gw; R[gpr].y2 = gh;
    ga = 0;  Sweep(0,100,0,0,1);
    printf("area = %d\n",ga);
    system ("pause");
}
