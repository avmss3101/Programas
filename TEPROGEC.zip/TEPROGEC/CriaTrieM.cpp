/* Insere palavras na Trie e permite que o usu�rio fa�a buscas de palavras na Trie. */
#include <iostream>
using namespace std;
struct node {
    int nf; // 0 quando n�o forma uma palavra; cc. n�mero de vezes a palavra foi inserida na Trie
    node* pont[26]; //Ponteiros para n�s de 'a' at� 'z'
};

node* T;
string S;

void InsereTrie(void)
{   int j, d, k, i;  node *p, *q;
    p = T;
    for(j = 0; j < S.length(); j++)
    {   d = tolower(S[j]) - 'a'; //converte os caracteres em min�sculo
        if (p->pont[d] == NULL)
        {
            q = new (node);  for (i=0; i<26; i++) q->pont[i] = NULL;
            q->nf = 0;  p->pont[d] = q;  p = q;
        }
        else p = p->pont[d];
    }
    p->nf++;
}

void ImprimePalavrasTrie(node* p, string t)
{    int d;
     if (p->nf)  cout << t << " (" << p->nf << ")" << endl; //Verifica se no node tem uma palavra, se sim imprime ela e o numero de ocorrencia dela
     for (d=0; d < 26; d++)
         if (p->pont[d] != NULL)
         {
             t += 'a' + d;
             ImprimePalavrasTrie(p->pont[d], t);
             t.erase(t.length() - 1); //t.pop_back() //c++11
         }
}

bool BuscaPalavraTrie(node *p, string t){
    int i, k, pl;
    k = t.size();
    for(i = 0; i < k; i++){
        pl = t[i] - 'a';
        if(p->pont[pl] != NULL){
            p = p->pont[pl];
        }
        else return false;
    }
    if(p->nf) return true;
    else return false;
}


int main()
{   int i, np, npb;
    T = new (node);  T->nf = 0;  for (i=0; i<26; i++)  T->pont[i] = NULL; //Cria Trie

    cout << "Numero de palavras (entre com as palavras em minusculo): ";
    cin >> np;
    for (i=1; i<=np;++i)
    {   cout <<"Palavra " << i <<": ";
        cin >> S;
        InsereTrie();
    }
    cout<<endl;
    cout << "Palavras na Trie: " << endl;
    S.clear();  ImprimePalavrasTrie(T, S);
    cout<<endl;
    cout << "Insira o numero de palavras que deseja buscar: " << endl;
    cin >> npb;

    for (i=1; i<=npb;++i)
    {   cout <<"Palavra para busca" << i <<": ";
        cin >> S;
        cout << "Esta na trie? ";
        if(BuscaPalavraTrie(T, S)) cout << "Sim" << endl;
        else cout << "Nao" << endl;
    }
    return 0;
}


