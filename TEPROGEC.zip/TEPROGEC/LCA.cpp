/* 	UERJ - Universidade do Estado do Rio de Janeiro
 *	T�picos Especiais em Algoritmos - Prof. Paulo Eust�quio Duarte Pinto
 *	Aula 2 - RMQ e LCA
 *	Implementa��o da Redu��o LCA -> RMQ por Giancarlo Fran�a
 */

#include <iostream>
#include <vector>
#define NMAX 1000
#define addFilho filhos.push_back
#define nFilhos filhos.size()
#define LCA(A,B) E[RMQ(H[A],H[B])]
using namespace std;

//ATEN��O: 	LCA n�o � uma fun��o, as chamadas s�o diretamente convertidas
//			em RMQ na macro acima.

//Estrutura da �rvore: array de n�s com �ndices dos filhos
struct no {
	vector<int> filhos;
};

no T[NMAX]; 
//Estruturas e vari�veis auxiliares para a DFS e o AE
int E[3*NMAX], L[3*NMAX], H[NMAX], M[3*NMAX][50], ii;

//Constru��o do circuito euleriano, e dos arrays L e H
void dfs(int n, int nv) {
	int f;
	E[ii]=n; L[ii]=nv; 
	H[n]=ii++; //Primeira ocorr�ncia do n� n
	for(f=0;f<T[n].nFilhos;++f) { //Visita todos os filhos de n
		dfs(T[n].filhos[f], nv+1);
		E[ii]=n; L[ii++]=nv;
	}
}

//RMQ com Array Esparso
int menor(int a, int b) {
	return (L[b]>L[a]) ? a : b;
}

void arrayEsparso(int N) {
	N *= 2;
	int i, j;
    for (i = 0; i < N; ++i) M[i][0] = i;
    for (j = 1; 1<<j <= N; ++j)
        for (i = 0; i+(1<<j)-1 < N; ++i) {
        	M[i][j] = menor(M[i][j-1],M[i+(1<<(j-1))][j-1]);
        }
}

int RMQ(int c, int f) {
	if (c>f) {int aux = c; c=f; f=aux; } //Troca para evitar consultas inv�lidas
	int tam = f-c+1;
	int k;
	for (k=1; 1 << k <= tam; ++k); --k; //c�lculo de piso(log(tam))
	return menor(M[c][k], M[f-(1<<k)+1][k]);
}

////////////////////////////////
int main() {
	//Descri��o da �rvore (mesma dos slides)
	T[1].addFilho(2); T[1].addFilho(3);
	T[2].addFilho(4); T[2].addFilho(5); T[2].addFilho(6);
	T[3].addFilho(7); T[3].addFilho(8);
	T[4].addFilho(9); T[4].addFilho(10);
	T[7].addFilho(11); T[7].addFilho(12);
	T[8].addFilho(13);
	T[11].addFilho(14); T[11].addFilho(15);
	T[13].addFilho(16);
	//Consultas
	ii=0; dfs(1,0); arrayEsparso(16);
	cout<<"LCA(15,16) = "<<LCA(15,16)<<endl;
	cout<<"LCA(9,6) = "<<LCA(9,6)<<endl;
	cout<<"LCA(10,11) = "<<LCA(10,11)<<endl;
	cout<<"LCA(7,14) = "<<LCA(7,14)<<endl;
	cout<<"LCA(1,1) = "<<LCA(1,1)<<endl;
	return 0;
}
